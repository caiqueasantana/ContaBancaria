
package banco.dao;

import banco.model.Conta;
import banco.database.Conexao;

import java.sql.*;

public class ContaDAO {
    public Conta buscarPorCpfEConta(String cpf, String numeroConta) {
        String sql = "SELECT * FROM contas WHERE cpf = ? AND numeroConta = ?";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            stmt.setString(2, numeroConta);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Conta(
                    rs.getString("numeroConta"),
                    rs.getString("tipoConta"),
                    rs.getDouble("saldo"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("senha")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
