
package banco.model;

public class Conta {
    String numeroConta, tipoConta;
    double saldo;
    String nome, cpf, senha;

    public Conta(String numeroConta, String tipoConta, double saldo, String nome, String cpf, String senha) {
        this.numeroConta = numeroConta;
        this.tipoConta = tipoConta;
        this.saldo = saldo;
        this.nome = nome;
        this.cpf = cpf;
        this.senha = senha;
    }

    public String getNome() { return nome; }
    public String getCpf() { return cpf; }
    public String getSenha() { return senha; }
    public String getNumeroConta() { return numeroConta; }
    public String getTipoConta() { return tipoConta; }
    public double getSaldo() { return saldo; }
}
