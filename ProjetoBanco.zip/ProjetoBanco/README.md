# Projeto Banco Digital em Java com JDBC

Leia o `sql/dados.sql` para importar dados simulados.
Configure `Conexao.java` com seu usuário e senha do MySQL.
